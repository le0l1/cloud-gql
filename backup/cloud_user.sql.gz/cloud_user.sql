-- Adminer 4.7.1 PostgreSQL dump

DROP TABLE IF EXISTS "cloud_user";
DROP SEQUENCE IF EXISTS cloud_user_id_seq;
CREATE SEQUENCE cloud_user_id_seq INCREMENT 1 MINVALUE 1 MAXVALUE 2147483647 START 1 CACHE 1;

CREATE TABLE "public"."cloud_user" (
    "id" integer DEFAULT nextval('cloud_user_id_seq') NOT NULL,
    "name" character varying NOT NULL,
    "password" character(64) NOT NULL,
    "phone" character varying(20) NOT NULL,
    "salt" character varying NOT NULL
) WITH (oids = false);

COMMENT ON COLUMN "public"."cloud_user"."id" IS '用户id';

COMMENT ON COLUMN "public"."cloud_user"."name" IS '用户名称';

COMMENT ON COLUMN "public"."cloud_user"."password" IS '用户密码';

COMMENT ON COLUMN "public"."cloud_user"."phone" IS '用户手机号';

COMMENT ON COLUMN "public"."cloud_user"."salt" IS '用户哈希盐值';

INSERT INTO "cloud_user" ("id", "name", "password", "phone", "salt") VALUES
(1006,	'leo',	'7b05140898187d1d375d24a9727192602ef695157159d8c66844b5c990c00d29',	'123124234',	'ibkDQquNVJfyAltEDVf/zgW07Piq9ArhXiOHlXzNvw3gdWgVf+TmRGPXuHOhmDWySnQdM2WedHIDlYj2dsnXIwwggRfpkOFKX6xXUU355U5+bqJ7I0Y4cp9F/Te8iiYEEZMNzMUzG/MVTUQ5bes6/Q3haX3INBKnskjW/LPTxMxKULLkrbnkBfkn6ieOuhRr0VWQkuuptbACRfiUianz1P0ZDQ8BmqZQ2aB7OhQ5zYaLXft1fpFXByotUiwyrV0Mw8PAGlXnCPdqJHK6CJ7mlXWBWbtMgMxrFH/L80QmqPKmNf8IBA1SCL0LEZ/52HXxrS+YYUhHeFTlrKM7aesA2w==');

-- 2019-04-23 09:40:45.405489+00
